/*		  Implementierung Quadrat	*/

# include "sqr.h"

int sqr( int i ) {
	return i * i;
}
