/* AP 30-Aug-2012 fac.h 			*/
/*		  Deklaration Fakultaet		*/

# ifndef __fac_h
# define __fac_h

# define FAC "fac"

extern int fac( int i );

# endif
