/* AP 30-Aug-2012 hello.c */

# include <stdio.h>

main() {
	printf("Hello World\n");
}


