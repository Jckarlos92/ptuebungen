/*		  Deklaration Quadrat		*/

# ifndef __sqr_h
# define __sqr_h

# define SQR "sqr"

extern int sqr( int i );

# endif
