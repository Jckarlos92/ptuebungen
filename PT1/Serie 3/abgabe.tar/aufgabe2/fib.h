/* AP 30-Aug-2012 fib.h				*/
/*		  Deklaration Fibonacci-Zahlen	*/


# ifndef __fib_h
# define __fib_h

# define FIB "fib"

extern int fib( int i );

# endif
