#ifndef ATOI_H
#define ATOI_H

long int atoi(const char * s);

#endif
