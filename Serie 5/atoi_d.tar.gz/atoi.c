#include <stdio.h>

long int atoi( const char * s ) {

	int i = 0;
	long int n=0;
	int sign = 1;

	if (s[0]== '-') {
		sign = -1;
	}
	int help;
	if (sign==1) {
		help=0;
	} else {
		help=1;
	}
	if (s[0+help]=='0'&&s[1+help]=='x'){
		for (i=2+help; (s[i] >= '0'&& s[i] <= '9')|| (s[i]>='A'&&s[i]<='F') || (s[i]>='a'&&s[i]<='f'); i++) {
			if (s[i] >= '0'&& s[i] <= '9') { 
				n = 16*n + (s[i]-'0');
			} else if (s[i]>='A'&&s[i]<='F') {
				n = 16*n + (s[i]-'A'+10);
			} else {
				n = 16*n + (s[i]-'a'+10);
			}
		}
	}  else {
		for (i=0+help; s[i] >= '0'&& s[i] <= '9'; i++) {
			n = 10*n + (s[i]-'0');
		}
	}
	return n*sign;
}
