#include <stdio.h>
#include "atoi.h"

int main (int argc, char * argv[]) {
	int i;
	for (i=1; i<argc; i++) {
		long int a=atoi(argv[i]);
		printf("%ld\n", a);
		printf("%d\n", i);
	}
	return 0;
}
